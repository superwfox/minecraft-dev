# 邮票卡片展示动画 · Vue 3

按参考视频的顺序重建：模糊蒙版展开 → 卡片出现 → 加载环变为勾选 → 卡片绕竖轴翻转 → 缩小并移到左侧 → 显示摘要 → 恢复初始胶囊。背景是黑白灰的深色低对比棋盘格（`#202020` / `#323232`）；蒙版内部保持模糊，沿四周圆角羽化过渡到外部清晰背景。默认播放速度为 **0.8 倍**，完整一轮 **4.375 秒**。预览视频按 **840 × 600、120fps** 直接渲染，宽高均为上一版的两倍。

`src/components/StampCardIsland.vue` 是可单独复制的组件，**只依赖 Vue 3.3+**（演示使用 3.5.43）。动画使用浏览器 Web Animations API；不需要 GSAP、Framer Motion 或额外图标包。

本版解码了原视频全部 **112 帧（30fps）**，测量每帧蒙版轮廓及 89 个可见卡片边界框，去除亚像素分割噪声后用连续三次样条重建位移与尺寸。原片时间域以 240Hz 重采样为 **897 个轨迹点**；旋转角度由投影宽高比、正反面转向估计，接近侧面时逐帧校正。高频轨迹点是插值，原视频实际仍只有 112 帧；无法从这些画面唯一恢复原生弹簧参数和摄像机参数。

播放不再在每个关键点重新缓入缓出。卡片通过 `transform`、透明度运动，羽化蒙版在固定画布上变形；动画的 `width` / `height` 仅用于 SVG 图形几何，不改变 HTML 盒子的布局尺寸。浏览器按屏幕实际刷新率插值，无逐帧 Vue 更新或布局测量。轨迹在模块级共享，尺寸变换后缓存，重播复用。

## 最快接入已有项目

1. 复制 `StampCardIsland.vue` 到你的组件目录。
2. 将现有邮票卡片放进默认插槽；卡片的最外层需要填满插槽的宽高。
3. 业务完成后调用 `play()`。它只是成功展示动画，不负责请求、加载或保存邮票。

```vue
<script setup lang="ts">
import { ref } from 'vue'
import StampCardIsland from './components/StampCardIsland.vue'
import StampCard from './components/StampCard.vue'

const animation = ref<InstanceType<typeof StampCardIsland>>()

async function showCollectedStamp() {
  // 在你的收藏 API 返回成功之后调用。
  await animation.value?.play()
}
</script>

<template>
  <button type="button" @click="showCollectedStamp">展示收藏动画</button>

  <StampCardIsland
    ref="animation"
    label="已收入邮册"
    :card-width="128"
    :card-height="180"
  >
    <StampCard style="width: 100%; height: 100%" />

    <template #back>
      <div class="my-stamp-back">邮票背面</div>
    </template>
  </StampCardIsland>
</template>
```

如果你的卡片只是图片，可以直接使用：

```vue
<StampCardIsland ref="animation" label="¥ 1.20">
  <img
    src="/stamps/crane.webp"
    alt="鹤归邮票"
    style="display:block;width:100%;height:100%;object-fit:cover"
  />
</StampCardIsland>
```

图片应预先加载；调用前可等待图片的 `decode()`，避免卡片出场时图片仍为空白。

## 属性

| 属性 | 默认值 | 说明 |
| --- | --- | --- |
| `cardWidth` | `154` | 展开后的卡片宽度，px；支持 48—400 |
| `cardHeight` | `98` | 展开后的卡片高度，px；支持 48—400 |
| `cardRadius` | `8` | 卡片正反面的圆角，px |
| `label` | `已收入邮册` | 收拢胶囊右侧摘要；过长时省略 |
| `successLabel` | `邮票已收入邮册` | 屏幕阅读器播报；只播报一次结果 |
| `idleLabel` | 空字符串 | 初始胶囊内的可选文字 |
| `duration` | `3500` | 基准时长，ms；实际时长为 `duration / speed`；支持 500—15000 |
| `speed` | `0.8` | 播放倍率；默认一轮 4375ms；演示的细看模式为 0.4 倍；支持 0.25—4 |
| `blur` | `8` | 蒙版内部的背景模糊半径，px，支持 0—64 |
| `feather` | `12` | 四周边缘向内羽化的宽度，px，支持 0—40；短胶囊自动限制为最短边的 1/4；设为 0 可关闭羽化 |
| `backgroundMode` | `live` | `live` 取样实际页面；`checkerboard` 采用固定棋盘格及缓存的模糊纹理 |
| `theme` | `dark` | 深色或浅色主题；影响棋盘格、色罩与默认图标颜色 |
| `inkColor` | 随主题 | 覆盖图标及摘要颜色；深色默认 `#ececec`，浅色默认 `#343434` |
| `respectReducedMotion` | `true` | 系统开启减少动态效果时，采用简短的摘要淡入淡出，省略翻转 |

Vue 模板使用短横线形式，例如 `:card-width="128"`。

## 插槽、方法与事件

| 接口 | 用途 |
| --- | --- |
| 默认插槽 | 卡片正面；整个过程中只使用同一个卡片实例 |
| `#back` | 卡片背面；不提供时使用银灰色背面 |
| `#summary` | 自定义摘要内容，覆盖 `label` |
| `#idle` | 初始胶囊内容，覆盖 `idleLabel` |
| `play(): Promise<boolean>` | 播放一轮；正常完成返回 `true`，中止返回 `false` |
| `cancel()` / `reset()` | 中止并恢复初始状态 |
| `isPlaying` / `phase` | 通过组件 ref 读取当前播放状态 |
| `@start` / `@complete` / `@cancel` | 播放开始、完成或中止 |
| `@phase-change` | `opening → display → success → folding → compact → closing → idle`；减少动态效果时省略中间步骤 |

重复调用 `play()` 会替换上一轮，不会叠加动画。组件卸载时自动取消轨道、清理定时器和尺寸监听；浏览器页面缩窄时整体等比缩放。`play()` 需要组件已挂载，在 SSR 阶段不会播放。

外层默认预留完整展开高度，避免展开时挤动页面。需要浮在页面顶部时，让你的外层容器负责 `position: fixed` 或 `absolute`；本组件不修改全局滚动和层级。卡片仅用于展示，组件内部不接收点击；交互按钮应放在组件外部。动画播放过程中保持卡片尺寸不变，完成后再调整。

## 加载圈与胶囊同步

加载圈在前 14% 时间内完全隐藏（默认速度下约 613ms）。此后同时根据胶囊高度、卡片显示程度及透视投影后的可用间距决定淡入权重，避免胶囊仍然较小时加载圈就出现在外面，也避免较大的卡片与加载圈重叠。

加载圈和随后出现的勾选都复用胶囊的逐时刻高度、位移与同一个底部位置，保留 34px 的底部间距；收缩到较小形状时位置自动限制在竖向中心。它们使用同一时间轴上的 897 个轨迹点，随胶囊展开、收拢而运动。加载圈位置和旋转同时插值；交接为勾选时不会跳回固定高度。

## 蒙版内部模糊与边缘羽化

蒙版内部显示完整的背景模糊结果，四周边界沿圆角形状平滑淡出到清晰背景；邮票、文字和图标保持清晰。`blur` 控制内部模糊半径，`feather` 独立控制边缘过渡宽度。例如：

```vue
<StampCardIsland ref="animation" :blur="8" :feather="12" :speed="0.8" theme="dark">
  <StampCard style="width:100%;height:100%" />
</StampCardIsland>
```

羽化改变的是模糊结果的混合权重，不是逐像素可变的高斯半径。使用同一个 SVG alpha 蒙版同时覆盖模糊背景和轻微色罩，避免色罩在边界留下硬线。16 层嵌套圆角矢量形状用 smoothstep 权重构成柔和过渡，无多块渐变拼接，也不为蒙版本身逐帧运行高斯滤镜。形状随原片拟合的尺寸和位移运动；短胶囊自动收窄羽化，保留充分模糊的内部区域。多个实例分别持有唯一的蒙版 ID；SSR 首屏采用初始胶囊裁剪，挂载后切换到羽化蒙版。

默认 `live` 模式通过一层 `backdrop-filter` 取样实际页面内容。演示采用 `background-mode="checkerboard"`：组件对自有棋盘格做周期高斯卷积，生成 64 × 64 像素的可平铺 PNG，按模糊半径缓存；播放时复用这张静态纹理，只改变矢量蒙版，不逐帧运行背景滤镜或重新捕获整页。纹理缓存按主题与模糊半径区分，由多个组件共享，最多保留 8 种组合。清晰底图也使用零模糊半径生成的平铺纹理；底图和模糊副本的原点对齐。64 像素纹理对应 32 CSS 像素，高像素比下仍能保持准确的棋盘格排列。

羽化蒙版直接用于背景滤镜层自身，组件父层不设置 `opacity < 1`、`filter` 或 `mask` 来截断背景取样。接入时，背景需要真实位于组件后面。

需要模糊你的集邮项目本身的内容时，省略 `background-mode` 即可使用 `live`。棋盘格缓存仅适用于这个已知静态背景；实时取样的开销随 `blur` 和取样面积变化。

## 运行完整演示

完整演示使用 Vite 7，建议 Node.js 22.12 或更新版本。复制单个组件到已有项目时，无须采用这个演示的构建工具。

```bash
npm install
npm run dev
```

```bash
npm run build
npm run preview
```

如果只想看效果，直接用浏览器打开同目录的 `preview.html`。它已经内嵌 Vue、演示代码和样式，不需要安装依赖或联网。

演示包含三个原创 SVG 邮票图案（鹤归、山色、潮汐），均为虚构设计练习，并非真实发行邮票。它们用于说明插槽可以替换内容，不是动画组件的必要依赖。内嵌预览包含 Vue 的 MIT 许可运行时。

## 已验证

TypeScript 检查与 Vite 生产构建通过。Chromium 中实际检查了完整播放、连续重播、中止、组件卸载、事件回调立即中止、128 × 180 竖版卡片、240 × 160 与 400 × 400 卡片、320px 窄屏、系统减少动态效果模式、多实例蒙版、关闭羽化及真实背景取样。逐时刻检查加载圈和勾选的可见范围均在圆角蒙版内，加载圈不与卡片重叠；前段保持完全隐藏。羽化蒙版已以像素检查确认内部完全覆盖、边界存在多个连续过渡等级且无拼接细线。未在真实 iOS Safari 设备上运行验证。

本次 Chromium 正常多进程环境中，从调用至结束约 4.51 秒，记录约 262 次刷新回调，间隔中位数约 16.7ms、P95 约 16.8ms；记录到 1 次超过 50ms 的间隔，统计包含轨道初始化时间。该结果对应本次环境与固定棋盘格场景，不是所有设备的帧率保证。视频以设备像素比 2 重新渲染为 840 × 600、120fps、525 帧，长度 4.375 秒，未对旧视频做放大处理。
