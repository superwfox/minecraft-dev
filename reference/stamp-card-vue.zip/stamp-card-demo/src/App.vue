<script setup lang="ts">
import { computed, ref } from 'vue'
import StampCardIsland from './components/StampCardIsland.vue'
import StampFace from './components/StampFace.vue'

const stamps = [
  { id: 'crane', title: '鹤归', subtitle: '水岸来信', number: '001', color: '#788e76' },
  { id: 'mountain', title: '山色', subtitle: '远山入册', number: '002', color: '#527269' },
  { id: 'sea', title: '潮汐', subtitle: '海上的风', number: '003', color: '#638b8c' },
] as const
const selected = ref(0)
const active = computed(() => stamps[selected.value]!)
const island = ref<InstanceType<typeof StampCardIsland>>()
const playing = ref(false)
const slow = ref(false)
const phase = ref('idle')
const phases: Record<string, string> = {
  idle: '准备就绪', opening: '展开', display: '展示卡片', success: '收藏确认',
  folding: '翻转收纳', compact: '收回胶囊', closing: '恢复初始状态',
}
const completed = ref(false)

async function collect() {
  completed.value = false
  const finished = await island.value?.play()
  if (finished) completed.value = true
}
</script>

<template>
  <div class="page">
    <header class="header">
      <a class="wordmark" href="#"><span class="wordmark-icon">邮</span> 方寸 <span class="wordmark-en">FANGCUN</span></a>
      <span class="header-note">一枚邮票，一次珍藏。</span>
    </header>

    <main>
      <div class="intro"><span class="eyebrow">THE LITTLE MOMENT OF COLLECTING</span><h1>把喜欢，收入方寸。</h1><p>轻轻展开，转身落定。让收藏的那一刻，也值得回味。</p></div>
      <section class="workbench" aria-label="邮票收藏动画演示">
        <div class="collection">
          <div class="section-heading"><span>本期邮票</span><span class="quiet">原创演示图案 / 3 枚</span></div>
          <div class="large-stamp"><StampFace :variant="active.id" /><div class="postmark" aria-hidden="true">方 寸<br /><small>COLLECTED</small></div></div>
          <div class="stamp-info"><div><span class="quiet">NO. {{ active.number }}</span><h2>{{ active.title }}<span>{{ active.subtitle }}</span></h2></div><span class="denomination">¥ 1.20</span></div>
          <div class="stamp-options" role="group" aria-label="选择邮票">
            <button v-for="(stamp, index) in stamps" :key="stamp.id" type="button" :aria-pressed="selected === index" :disabled="playing" :aria-label="`选择${stamp.title}邮票`" @click="selected = index; completed = false"><span class="option-art"><StampFace :variant="stamp.id" /></span><span>{{ stamp.title }}</span><span v-if="selected === index" class="selected-dot" :style="{ background: stamp.color }"></span></button>
          </div>
        </div>

        <div class="animation-panel">
          <div class="section-heading"><span>收藏瞬间</span><span class="status"><i :class="{ moving: playing }"></i>{{ phases[phase] }}</span></div>
          <div class="preview-area">
            <StampCardIsland ref="island" background-mode="checkerboard" label="¥ 1.20" :success-label="`${active.title}已收入邮册`" :speed="slow ? .4 : .8" @start="playing = true" @complete="playing = false" @cancel="playing = false" @phase-change="phase = $event">
              <StampFace :variant="active.id" />
              <template #back><div class="stamp-back"><span>方寸</span><small>A LITTLE WORLD</small></div></template>
            </StampCardIsland>
          </div>
          <div class="play-controls"><button class="play-button" type="button" @click="collect"><span>{{ playing ? '重新播放' : completed ? '再收藏一次' : '播放收藏动画' }}</span><svg viewBox="0 0 20 20" width="18" height="18" fill="none" aria-hidden="true"><path d="M4 10h12m-5-5 5 5-5 5" stroke="currentColor" stroke-width="1.5" /></svg></button><label class="slow-label"><input v-model="slow" type="checkbox" :disabled="playing" />{{ slow ? '0.4× · 细看动作' : '0.8× · 再慢一倍' }}</label></div>
          <div class="motion-steps"><span :class="{ active: ['opening','display'].includes(phase) }">展开</span><i></i><span :class="{ active: phase === 'success' }">确认</span><i></i><span :class="{ active: phase === 'folding' }">翻转</span><i></i><span :class="{ active: ['compact','closing'].includes(phase) }">收纳</span></div>
        </div>
      </section>
      <footer><span>方寸之间，另有天地。</span><span>Vue 3 · 可复用卡片动画</span></footer>
    </main>
  </div>
</template>

<style>
* { box-sizing: border-box; }
body { color-scheme: dark; margin: 0; background: #121212; color: #e7e7e7; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif; -webkit-font-smoothing: antialiased; }
button, input { font: inherit; }
button { cursor: pointer; }
button:disabled { cursor: default; }
button:focus-visible, a:focus-visible, input:focus-visible { outline: 3px solid #bbbbbb; outline-offset: 5px; }
.page { max-width: 1120px; margin: 0 auto; padding: 30px 48px 26px; }
.header { display: flex; justify-content: space-between; align-items: center; padding-bottom: 22px; border-bottom: 1px solid #353535; }
.wordmark { text-decoration: none; color: inherit; display: inline-flex; align-items: center; gap: 12px; font-size: 18px; font-weight: 600; letter-spacing: 4px; }
.wordmark-icon { width: 30px; height: 32px; display: grid; place-items: center; border: 1px solid #919191; font: 18px 'Songti SC', serif; letter-spacing: 0; }
.wordmark-en { font-size: 10px; font-weight: 400; letter-spacing: 2px; color: #9b9b9b; margin-left: 4px; }
.header-note { font-size: 12px; letter-spacing: 1px; color: #a3a3a3; }
.intro { margin: 44px 0 32px; }
.eyebrow { font-size: 9px; letter-spacing: 2px; color: #9e9e9e; }
h1 { margin: 14px 0 14px; font: 400 38px/1.3 'Songti SC', 'Noto Serif CJK SC', 'SimSun', serif; letter-spacing: 2px; }
.intro p { color: #a6a6a6; font-size: 13px; margin: 0; letter-spacing: .5px; line-height: 1.8; }
.workbench { display: grid; grid-template-columns: 1fr 1fr; gap: 42px; background: #1b1b1b; border: 1px solid #393939; border-radius: 18px; padding: 28px 32px 30px; box-shadow: 0 16px 35px -30px #00000055; }
.collection { padding-right: 32px; border-right: 1px solid #393939; }
.section-heading { display: flex; justify-content: space-between; align-items: center; gap: 8px; font-size: 12px; }
.quiet { color: #a4a4a4; font-size: 10px; letter-spacing: .8px; }
.large-stamp { position: relative; width: 100%; max-width: 330px; aspect-ratio: 308 / 196; margin: 26px auto 22px; transform: rotate(-3deg); box-shadow: 1px 9px 12px -10px #00000099; }
.postmark { position: absolute; right: -14px; bottom: 0; width: 77px; height: 77px; display: grid; align-content: center; justify-content: center; text-align: center; border: 2px solid #c99d7899; outline: 1px solid #c99d7877; outline-offset: -7px; border-radius: 50%; color: #d0a885c9; font-family: 'Songti SC', serif; font-size: 17px; transform: rotate(16deg); line-height: 1.5; }
.postmark small { font: 7px system-ui; letter-spacing: 1px; }
.stamp-info { display: flex; justify-content: space-between; align-items: center; margin: 0 0 26px; }
h2 { font: 24px 'Songti SC', 'SimSun', serif; margin: 7px 0 0; letter-spacing: 2px; }
h2 span { font: 11px system-ui; color: #a8a8a8; margin-left: 12px; letter-spacing: 0; }
.denomination { font: 24px Georgia, serif; color: #dedede; }
.stamp-options { display: flex; gap: 12px; }
.stamp-options button { position: relative; flex: 1; min-width: 0; background: transparent; padding: 6px 6px 10px; border: 1px solid #424242; border-radius: 7px; color: #a6a6a6; font-size: 10px; transition: border-color .15s, background .15s; }
.stamp-options button[aria-pressed="true"] { border-color: #a7a7a7; background: #303030; color: #e7e7e7; }
.stamp-options button:disabled { opacity: .65; }
.option-art { display: block; aspect-ratio: 308 / 196; margin-bottom: 9px; }
.selected-dot { position: absolute; right: 9px; bottom: 13px; width: 4px; height: 4px; border-radius: 50%; }
.status { display: flex; align-items: center; gap: 6px; font-size: 10px; color: #a6a6a6; white-space: nowrap; }
.status i { width: 5px; height: 5px; background: #9c9c9c; border-radius: 50%; }
.status i.moving { background: #c4c4c4; }
.preview-area { position: relative; min-height: 277px; padding-top: 28px; display: flex; justify-content: center; margin: 20px 0 22px; border-radius: 12px; }
.stamp-back { height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 10px; background: #dedccb; color: #8d9685; border: 6px solid #e5e2d4; }
.stamp-back span { font: 20px 'Songti SC', serif; letter-spacing: 6px; padding-left: 6px; }
.stamp-back small { font-size: 5px; letter-spacing: 2px; }
.play-controls { display: flex; flex-direction: column; align-items: center; gap: 17px; }
.play-button { display: flex; gap: 28px; align-items: center; justify-content: center; background: #dddddd; color: #242424; border: 0; border-radius: 8px; min-width: 210px; min-height: 45px; padding: 12px 21px; font-size: 12px; letter-spacing: .5px; }
.play-button:hover { background: #ededed; }
.slow-label { display: inline-flex; align-items: center; gap: 7px; color: #ababab; font-size: 10px; min-height: 26px; }
.slow-label input { margin: 0; accent-color: #c5c5c5; }
.motion-steps { display: flex; justify-content: center; align-items: center; gap: 10px; margin-top: 18px; color: #8a8a8a; font-size: 10px; }
.motion-steps i { width: 17px; height: 1px; background: #4a4a4a; }
.motion-steps .active { color: #e0e0e0; }
footer { display: flex; justify-content: space-between; gap: 12px; padding: 22px 0 0; color: #929292; font-size: 10px; letter-spacing: 1px; }
@media (max-width: 800px) {
  .page { padding: 24px; }.workbench { gap: 26px; padding: 24px; }.collection { padding-right: 24px; }.large-stamp { margin-top: 38px; }.postmark { width: 62px; height: 62px; font-size: 14px; }.section-heading .quiet { display: none; }.wordmark-en { display: none; }h1 { font-size: 32px; }
}
@media (max-width: 620px) {
  .page { padding: 20px 18px; }.header-note { font-size: 10px; letter-spacing: 0; }.intro { margin: 30px 0 25px; }h1 { font-size: 28px; }.intro p { font-size: 12px; }.workbench { grid-template-columns: 1fr; gap: 28px; padding: 23px 20px; }.collection { padding: 0 0 24px; border-right: 0; border-bottom: 1px solid #393939; }.large-stamp { margin-top: 28px; width: 88%; }.preview-area { min-height: 265px; }.section-heading .quiet { display: inline; }footer { font-size: 9px; letter-spacing: 0; }.stamp-options button { min-height: 44px; }.slow-label { min-height: 44px; font-size: 11px; }
}
</style>
