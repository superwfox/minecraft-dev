<script setup lang="ts">
withDefaults(defineProps<{ variant?: 'crane' | 'mountain' | 'sea' }>(), { variant: 'crane' })
</script>

<template>
  <svg class="stamp-face" viewBox="0 0 308 196" xmlns="http://www.w3.org/2000/svg" role="img" :aria-label="variant === 'crane' ? '鹤归邮票' : variant === 'mountain' ? '山色邮票' : '潮汐邮票'">
    <rect width="308" height="196" fill="#f2eee2" />
    <path d="M12 12h284v172H12z" fill="none" stroke="#c9c6b8" stroke-width="1" />
    <g fill="#f2eee2" stroke="#cbc7b9" stroke-width=".6">
      <circle v-for="n in 20" :key="`t${n}`" :cx="8 + n * 14" cy="5" r="3.3" />
      <circle v-for="n in 20" :key="`b${n}`" :cx="8 + n * 14" cy="191" r="3.3" />
      <circle v-for="n in 12" :key="`l${n}`" cx="5" :cy="8 + n * 14" r="3.3" />
      <circle v-for="n in 12" :key="`r${n}`" cx="303" :cy="8 + n * 14" r="3.3" />
    </g>
    <template v-if="variant === 'crane'">
      <rect x="22" y="22" width="264" height="122" fill="#8b9d82" />
      <circle cx="221" cy="56" r="23" fill="#d7b180" />
      <path d="M22 110Q86 72 151 105T286 91V144H22z" fill="#637e70" />
      <path d="M22 134Q94 111 170 125T286 120V144H22z" fill="#45645a" />
      <path d="M121 105C91 87 80 64 60 57C79 59 111 69 137 84C143 75 155 69 166 67C147 66 147 42 162 38C172 35 184 37 187 40L208 42L187 47C178 47 167 44 163 47C159 52 167 62 180 69C184 86 171 103 149 109Z" fill="#edead9" />
      <path d="M128 98C111 76 85 67 67 62L112 95Z" fill="#d1d7c9" />
      <path d="M146 108L143 133M156 107L161 132M137 133h13M156 132h14" fill="none" stroke="#242e2a" stroke-width="2" />
      <circle cx="181" cy="40" r="2" fill="#ba5440" /><circle cx="182" cy="43" r="1.2" fill="#30352e" />
      <path d="M29 130l4-25 4 25m-3-13 8-6M269 130l-2-23-5 23m5-15-8-5" stroke="#a8b99c" fill="none" stroke-width="1" />
      <text x="35" y="48" fill="#f3efdf" font-size="19" letter-spacing="5">鹤归</text>
      <text x="35" y="61" fill="#e5e5d4" font-size="6.5" letter-spacing="1.8">RETURN OF THE CRANE</text>
    </template>
    <template v-else-if="variant === 'mountain'">
      <rect x="22" y="22" width="264" height="122" fill="#d8d2bf" />
      <circle cx="242" cy="51" r="16" fill="#b45a43" />
      <path d="M22 114L86 57L121 87L165 46L237 117L286 75V144H22z" fill="#8c9b94" />
      <path d="M22 126L107 84L146 110L197 77L265 123L286 108V144H22z" fill="#527269" />
      <path d="M22 144L87 116L121 131L167 104L248 144z" fill="#294e49" />
      <path d="M144 67l21-21 30 31-28-10-7 10z" fill="#ede9d8" />
      <path d="M162 107l-7 10 8 6-14 10 2 11" stroke="#d0d6c5" stroke-width="2" fill="none" />
      <text x="35" y="48" fill="#324c44" font-size="19" letter-spacing="5">山色</text>
      <text x="35" y="61" fill="#415e54" font-size="6.5" letter-spacing="1.8">MOUNTAINS IN MIST</text>
    </template>
    <template v-else>
      <rect x="22" y="22" width="264" height="122" fill="#a5b7b2" />
      <circle cx="224" cy="52" r="20" fill="#e6d6b6" />
      <path d="M22 94q23-18 46 0t46 0t46 0t46 0t46 0t46 0v50H22z" fill="#648c8b" />
      <path d="M22 113q23-18 46 0t46 0t46 0t46 0t46 0t46 0v31H22z" fill="#32666b" />
      <path d="M22 119q23-18 46 0t46 0t46 0t46 0t46 0t46 0" stroke="#dbded0" stroke-width="1.3" fill="none" />
      <path d="M176 110l8-57v55M185 56l27 47-27-2zM166 112h49l-12 9h-28z" fill="#eae4d0" stroke="#385c5c" stroke-width="1" />
      <path d="M246 69q5-6 10 0q5-6 10 0" stroke="#426568" fill="none" stroke-width="1.4" />
      <text x="35" y="48" fill="#27494d" font-size="19" letter-spacing="5">潮汐</text>
      <text x="35" y="61" fill="#35585a" font-size="6.5" letter-spacing="1.8">LETTERS FROM THE SEA</text>
    </template>
    <g fill="#31443c" font-family="Georgia, 'Songti SC', serif">
      <text x="26" y="163" font-size="9" letter-spacing="3">中国邮政</text>
      <text x="26" y="177" font-size="6.5" letter-spacing="1.4">CHINA POST · DESIGN STUDY</text>
      <text x="275" y="172" font-size="24" text-anchor="end">1.20</text>
      <text x="275" y="182" font-size="6" text-anchor="end" letter-spacing="1.5">YUAN</text>
    </g>
  </svg>
</template>

<style scoped>
.stamp-face { display: block; width: 100%; height: 100%; }
</style>
